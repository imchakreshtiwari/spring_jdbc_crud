
public class Employee {

	private String address;
	private int id;
	/*public Employee(String address)
	{
		this.address=address;
	}
	
	public Employee()
	{
		System.out.println("default constructor");
	}
	public Employee(int id)
	{
		this.id=id;
	}*/
	public Employee(String address,int id)
	{
		this.address=address;
		this.id=id;
	}
	public void show()
	{
		System.out.println("name"+address);
        System.out.println("id"+id);
	}
/*	public void setAddress(String address)
	{
		this.address=address;
	}*/

}
