import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class QuestionMap {

	private int id;
	private  String name;
	Map<String,String> answermap;
	public QuestionMap(int id,String name,Map<String,String> answermap )
	{
		this.id=id;
		this.name=name;
		this.answermap=answermap;
	}
	
	public void displayinfo()
	{
		System.out.println(id+""+name);
		Set<Entry<String,String>> set=answermap.entrySet();
		Iterator<Entry<String,String>> itr=set.iterator();
		while(itr.hasNext())
		{
			Entry<String,String> entry=itr.next();
			System.out.println("answer is"+entry.getKey()+" username is"+entry.getValue());
		}
	}
}
