import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  

public class Test {  
public static void main(String[] args) {  
    Resource resource=new ClassPathResource("applicationContext.xml");  
    BeanFactory factory=new XmlBeanFactory(resource);  
    
    Student student=(Student)factory.getBean("studentbean"); 
    Employee emp=(Employee)factory.getBean("empbean");
    student.displayinfo();
    emp.show();
    
    ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
    Student student1=(Student)context.getBean("studentbean");  
    student1.displayinfo();  
    
    //for using aggregation
    ApplicationContext contextforobj=new ClassPathXmlApplicationContext("applicationContext.xml");
    Employeee1 empobj=(Employeee1)contextforobj.getBean("empbeansup");
    empobj.show();
    
    //for using list in xml file
  /*  ApplicationContext contextquestionlist=new ClassPathXmlApplicationContext("applicationContext.xml");
    Question ques=(Question)contextquestionlist.getBean("qalist");
    ques.displayinfo();*/

    //for taking value of answer from another class
    ApplicationContext contextquestionlistclass=new ClassPathXmlApplicationContext("applicationContext.xml");
    Question ques1=(Question)contextquestionlistclass.getBean("questionwithans");
    ques1.displayinfo();
    
    
    ApplicationContext contextquestionlistclassmap=new ClassPathXmlApplicationContext("applicationContext.xml");
    QuestionMap ques1map=(QuestionMap)contextquestionlistclassmap.getBean("questionwithansmap");
    ques1map.displayinfo();
    
}  
}  
