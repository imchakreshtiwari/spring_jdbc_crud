import java.util.Iterator;
import java.util.List;

public class Question {

	int id;
	String name;
	List<String> answers;
	List<Answer> answeragg;
	public Question()
	{
		System.out.println("default constructor");
	}
	
	//when answer value is directly from xml to list
	/*public Question(int id,String name,List<String> answers)
	{
		super();
		this.id=id;
		this.name=name;
		this.answers=answers;
	}*/
	
	//constructor for answer value coming from another class
	public Question(int id,String name,List<Answer> answeragg)
	{
		super();
		this.id=id;
		this.name=name;
		this.answeragg=answeragg;
	}
	
	public void displayinfo()
	{
		System.out.println(id+""+name);
		System.out.println("answers");
		Iterator<Answer> itr=answeragg.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}
