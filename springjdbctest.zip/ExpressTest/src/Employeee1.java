
public class Employeee1 {

	int id;
	String name;
	Address address;//aggregation

	public Employeee1(int id,String name,Address address)
	{
	this.id=id;
	this.name=name;
	this.address=address;
	}
	
	public void show()
	{
		System.out.println(id+""+name);
		System.out.println(address.toString());
		System.out.println(address.hashCode());
	}
}
