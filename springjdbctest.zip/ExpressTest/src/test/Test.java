package test;

import java.util.List;

import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;  
public class Test {  
  
public static void main(String[] args) {  
    ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");  
      
    //insert a record
/*    EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");  
    int status=dao.saveEmployee(new Employee(102,"Amit",35000));  
    System.out.println(status);  
          
    int status=dao.updateEmployee(new Employee(102,"Sonoo",15000)); 
    System.out.println(status); 
    
          
    Employee e=new Employee(); 
    e.setId(102); 
    int status=dao.deleteEmployee(e); 
    System.out.println(status);*/
    
/*    //Employeedao1
    EmployeeDao1 dao=(EmployeeDao1)ctx.getBean("edao");  
    boolean status=dao.saveEmployeeprep(new Employee(102,"Amit",35000));  
    System.out.println(status);
    */
    //Employeedao2
    EmployeeDao2 dao= (EmployeeDao2)ctx.getBean("edao"); 
    List<Employee> list=  dao.allEmployee();
    for(Employee e:list)
    {
    System.out.println(e);
    }
      
}  
  
}  
